// This prompts user to enter their name and updates the heading accordingly
const userName = prompt("Welcome! What's your name?");
const heading = document.getElementById("welcomeHeading");

if (userName) {
  heading.textContent = `${userName}'s Interactive Chart Builder`;
} else {
  heading.textContent = "Interactive Chart Builder";
}



let chart;
const chartTypeSelect = document.getElementById("chartType");
const datasetLabelInput = document.getElementById("datasetLabel");
const ctx = document.getElementById('myChart').getContext('2d');

function getChartData() {
  const rows = document.querySelectorAll('#dataTable tbody tr');
  const labels = [];
  const values = [];

  rows.forEach(row => {
    const label = row.cells[0].querySelector('input').value;
    const value = parseFloat(row.cells[1].querySelector('input').value);
    if (label && !isNaN(value)) {
      labels.push(label);
      values.push(value);
    }
  });

  return { labels, values };
}

function renderChart() {
  const { labels, values } = getChartData();
  const chartType = chartTypeSelect.value;
  const datasetLabel = datasetLabelInput.value;

  if (chart) chart.destroy();

  chart = new Chart(ctx, {
    type: chartType,
    data: {
      labels: labels,
      datasets: [{
        label: datasetLabel,
        data: values,
        backgroundColor: [
          '#3498db', '#e74c3c', '#2ecc71', '#9b59b6', '#f1c40f',
          '#1abc9c', '#34495e', '#d35400', '#c0392b', '#7f8c8d'
        ],
        borderWidth: 2,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: chartType !== 'pie' && chartType !== 'doughnut' }
      }
    }
  });
}

function addRow() {
  const tableBody = document.querySelector('#dataTable tbody');
  const row = document.createElement('tr');
  row.innerHTML = `
    <td><input type="text" placeholder="Label"></td>
    <td><input type="number" placeholder="Value"></td>
  `;
  tableBody.appendChild(row);
}

function removeRow() {
  const tableBody = document.querySelector('#dataTable tbody');
  if (tableBody.rows.length > 1) {
    tableBody.deleteRow(-1);
  }
}

// Initial render
renderChart();

// Event listeners
document.getElementById('dataTable').addEventListener('input', renderChart);
chartTypeSelect.addEventListener('change', renderChart);
datasetLabelInput.addEventListener('input', renderChart);
